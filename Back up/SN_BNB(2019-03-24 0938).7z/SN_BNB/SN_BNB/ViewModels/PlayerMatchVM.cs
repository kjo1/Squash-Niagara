﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SN_BNB.ViewModels
{
    public class PlayerMatchVM
    {
        public int PlayerID { get; set; }
        public string Name { get; set; }
    }
}
